import java.util.ArrayList;
import java.util.Arrays;

import javax.xml.crypto.Data;

public class KNNModel extends Model {
    
    private ArrayList<DataPoint> trainSet;
    private int k;
    private int passengerAlive;
    private int passengerDead;

    public KNNModel(int k){
        this.k = k;
        passengerAlive = 0;
        passengerDead = 0;
        trainSet = new ArrayList<DataPoint>();
    }

    private double getDistance(DataPoint p1, DataPoint p2){
        return Math.sqrt(Math.pow((p2.getF1() - p1.getF1()),2) + Math.pow((p2.getF2() - p1.getF2()),2));
    }

    public void train(ArrayList<DataPoint> data){
        for(DataPoint p : data){
            if(p.getType().equals("train"))
                trainSet.add(p);
            if(p.getLabel().equals("1"))
                passengerAlive++;
            else
                passengerDead++;
        }
    }

    public String test(ArrayList<DataPoint> data){
        DataPoint test = data.get(0);
        if(test.getType().equals("test")){
            Double array[][] = new Double[trainSet.size()][2];
            for(int i = 0; i < trainSet.size(); i++){
                array[i][0] = getDistance(test, trainSet.get(i));
                if(trainSet.get(i).getLabel().equals("1"))
                    array[i][1] = 1.0;
                else
                    array[i][1] = 0.0;
            }
            Arrays.sort(array, new java.util.Comparator<Double[]>() {
                public int compare(Double[] a, Double [] b) {
                    return a[0].compareTo(b[0]);
                }
            });
            int survivedCount = 0;
            int deadCount = 0;
            for(int i = 0; i < k; i++){
                if(array[i][1] == 1.0)
                    survivedCount++;
                else
                    deadCount++;
            }
            return survivedCount > deadCount ? "1" : "0";
        }
        return "";
    }

    public Double getAccuracy(ArrayList<DataPoint> data){
        int truePositive = 0;
        int falsePositive = 0;
        int falseNegative = 0;
        int trueNegative = 0;
        for(DataPoint p : data){
            ArrayList<DataPoint> temp = new ArrayList<DataPoint>();
            temp.add(p);
            String label = test(temp);
            if(label.equals("1") && p.getLabel().equals("1"))
                truePositive++;
            else if(label.equals("1") && p.getLabel().equals("0"))
                falsePositive++;
            else if(label.equals("0") && p.getLabel().equals("1"))
                falseNegative++;
            else if(label.equals("0") && p.getLabel().equals("0"))
                trueNegative++;
        }
        return (double)(truePositive + trueNegative) / (double)(truePositive + trueNegative + falsePositive + falseNegative);
    }

    public Double getPrecision(ArrayList<DataPoint> data){
        int truePositive = 0;
        int falseNegative = 0;
        for(DataPoint p : data){
            ArrayList<DataPoint> temp = new ArrayList<DataPoint>();
            temp.add(p);
            String label = test(temp);
            if(label.equals("1") && p.getLabel().equals("1"))
                truePositive++;
            else if(label.equals("0") && p.getLabel().equals("1"))
                falseNegative++;
        }
        return (double)(truePositive) / (double)(truePositive + falseNegative);
    }
}
